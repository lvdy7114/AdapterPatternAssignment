
public class CoffeeTouchScreenAdapter implements CoffeeMachineInterface {

	public static void main(String[] args) {
		
	OldCoffeeMachine machine = new OldCoffeeMachine();
	machine.selectA();
	machine.selectB();

	}
	

	@Override
	public void chooseFirstSelection() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chooseSecondSelection() {
		// TODO Auto-generated method stub
		
	}
	
		
	}

	


