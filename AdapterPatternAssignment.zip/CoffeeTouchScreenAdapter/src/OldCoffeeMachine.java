
public class OldCoffeeMachine {
	

	public void selectA() {
			System.out.println("Select A");
		}
		
	public void selectB() {
			System.out.println("Select B");
		}
}



