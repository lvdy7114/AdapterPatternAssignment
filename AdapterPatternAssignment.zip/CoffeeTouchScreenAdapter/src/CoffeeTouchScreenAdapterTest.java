import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CoffeeTouchScreenAdapterTest {

	@Test
	void testMain() {
		fail("Not yet implemented");
	}

	@Test
	void testChooseFirstSelection() {
		fail("Not yet implemented");
	}

	@Test
	void testChooseSecondSelection() {
		fail("Not yet implemented");
	}

}
